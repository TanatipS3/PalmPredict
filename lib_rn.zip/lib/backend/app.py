import os
from flask import Flask, request, jsonify
from flask_cors import CORS
from werkzeug.exceptions import BadRequest

app = Flask(__name__)
# Allow CORS for your app domain(s); for quick start we allow all origins
CORS(app, origins=os.getenv("CORS_ORIGINS", "*").split(","), supports_credentials=True)

# Limit upload size (Lambda limit is 6MB direct; bigger use S3 presigned URLs)
app.config['MAX_CONTENT_LENGTH'] = 10 * 1024 * 1024  # 10 MB

@app.errorhandler(BadRequest)
def handle_bad_request(e):
    return jsonify({"ok": False, "error": "bad_request", "detail": str(e)}), 400

@app.errorhandler(413)
def handle_large(e):
    return jsonify({"ok": False, "error": "payload_too_large"}), 413

@app.get("/health")
def health():
    return jsonify({"ok": True})

@app.post("/analyze")
def analyze():
    # Expect a multipart/form-data with a file field named "file"
    if "file" not in request.files:
        raise BadRequest("missing file")
    f = request.files["file"]

    # Save to Lambda's /tmp directory
    tmp_path = "/tmp/upload.jpg"
    f.save(tmp_path)

    # TODO: Replace this with your real inference / OpenCV / ML code
    result = {
        "life_line": "demo-life",
        "head_line": "demo-head",
        "heart_line": "demo-heart",
    }
    return jsonify({"ok": True, "data": result})

if __name__ == "__main__":
    # Run locally
    app.run(host="0.0.0.0", port=5000, debug=True)

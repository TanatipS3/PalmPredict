import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';


/// ---------- Data models ----------
class PalmResult {
  final String imageToken;            // not returned by the demo API yet
  final String lifeLinePrediction;
  final String headLinePrediction;
  final String heartLinePrediction;

  const PalmResult({
    required this.imageToken,
    required this.lifeLinePrediction,
    required this.headLinePrediction,
    required this.heartLinePrediction,
  });

  Map<String, dynamic> toJson() => {
        'lifeLinePrediction': lifeLinePrediction,
        'headLinePrediction': headLinePrediction,
        'heartLinePrediction': heartLinePrediction,
        'imageToken': imageToken,
      };
}

class ApiException implements Exception {
  final String message;
  final int? statusCode;

  const ApiException(this.message, {this.statusCode});

  @override
  String toString() =>
      'ApiException: $message${statusCode != null ? ' (Status: $statusCode)' : ''}';
}

/// ---------- Service ----------
class ApiService {
  // Point to your API Gateway base URL; can be overridden at build time
  static const String baseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'https://r6z1dwdcl0.execute-api.ap-southeast-1.amazonaws.com',
  );

  static const Duration defaultTimeout = Duration(seconds: 45);

  // Current live endpoints in the new backend
  static const String _health = '/health';
  static const String _analyze = '/analyze';

  /// Quick ping to ensure the API is up
  static Future<bool> health() async {
    final uri = Uri.parse('$baseUrl$_health');
    final resp = await http.get(uri).timeout(const Duration(seconds: 15));
    return resp.statusCode == 200;
  }

  /// Uploads an image via multipart/form-data to /analyze
  /// Returns PalmResult using fields provided by the cloud API.
  static Future<PalmResult> processPalm(File imageFile) async {
    try {
      final uri = Uri.parse('$baseUrl$_analyze');

      final request = http.MultipartRequest('POST', uri)
        ..files.add(
          await http.MultipartFile.fromPath(
            'file', // <-- field name expected by Flask app.py
            imageFile.path,
            contentType: MediaType('image', _guessExt(imageFile.path)),
          ),
        );

      final streamed = await request.send().timeout(defaultTimeout);
      final resp = await http.Response.fromStream(streamed);

      if (resp.statusCode != 200) {
        throw ApiException(
          'Server error: ${resp.statusCode} ${resp.body}',
          statusCode: resp.statusCode,
        );
      }

      final jsonMap = jsonDecode(resp.body) as Map<String, dynamic>;
      final ok = jsonMap['ok'] == true;
      if (!ok) {
        throw const ApiException('API returned ok=false');
      }

      final data = (jsonMap['data'] ?? {}) as Map<String, dynamic>;
      final life = (data['life_line'] ?? 'ไม่พบข้อมูล').toString();
      final head = (data['head_line'] ?? 'ไม่พบข้อมูล').toString();
      final heart = (data['heart_line'] ?? 'ไม่พบข้อมูล').toString();

      // The demo backend doesn't return an image_token yet, so leave blank.
      return PalmResult(
        imageToken: data['image_token']?.toString() ?? '',
        lifeLinePrediction: life,
        headLinePrediction: head,
        heartLinePrediction: heart,
      );
    } on TimeoutException {
      throw const ApiException('Server took too long (timeout)');
    } on SocketException {
      throw const ApiException('Network unavailable');
    } catch (e) {
      if (e is ApiException) rethrow;
      throw ApiException('Unexpected error: $e');
    }
  }

  /// Not available in the demo backend yet — keep for future use.
  /// When you add /get-mask-image on Flask, you can re-enable this.
  static Future<Uint8List?> fetchMaskImage(String token) async {
    // final uri = Uri.parse("$baseUrl/get-mask-image?token=$token");
    // final resp = await http.get(uri).timeout(const Duration(seconds: 60));
    // if (resp.statusCode == 200) return resp.bodyBytes;
    // throw ApiException('fetchMaskImage failed: ${resp.statusCode}');
    return null;
  }

  /// Not available in the demo backend yet — keep for future use.
  static Future<bool> uploadUserProfile({
    required String name,
    required String passcode,
    File? imageFile,
  }) async {
    // TODO: implement once /upload-user-profile exists on Flask
    return false;
  }

  /// Helper for MIME subtype from file extension
  static String _guessExt(String path) {
    final p = path.toLowerCase();
    if (p.endsWith('.png')) return 'png';
    if (p.endsWith('.jpeg') || p.endsWith('.jpg')) return 'jpeg';
    return 'jpeg';
  }
}


